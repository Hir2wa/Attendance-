<?php
session_start();

// Check if the student or lecturer is logged in
if (!isset($_SESSION['email']) && !isset($_SESSION['lecturer_email'])) {
    header('Location: login.php'); // Redirect to a common login page or respective login pages
    exit();
}
?>
