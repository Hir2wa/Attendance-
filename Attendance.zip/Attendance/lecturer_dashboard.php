<?php
session_start();

// Check if the lecturer is logged in
if (!isset($_SESSION['lecturer_logged_in']) || $_SESSION['lecturer_logged_in'] !== true) {
    header('Location: lecturer_login.php');
    exit();
}

// Retrieve lecturer email from session
$lecturer_email = $_SESSION['lecturer_email'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lecturer Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            margin-top: 0;
        }
        a {
            text-decoration: none;
            color: #007bff;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin: 10px 0;
            color: #fff;
            background-color: #007bff;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome, <?php echo htmlspecialchars($lecturer_email); ?>!</h1>
        <p>This is your dashboard. You can manage your attendance records and view relevant information here.</p>
        
        <a href="view_attendance.php" class="btn">View Attendance Records</a>
        <a href="mark_attendance.php" class="btn">Mark Attendance</a>
        <a href="chart_lecture.php" class="btn">chats</a>
        

       
        <a href="logout.php" class="btn">Logout</a>
    </div>
</body>
</html>
