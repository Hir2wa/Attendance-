<?php
$conn = new mysqli("localhost", "root", "", "attendancesystem");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['id']) && isset($_POST['password'])) {
    $id = $_POST['id'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Update the password in the database
    $stmt = $conn->prepare("UPDATE students SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $password, $id);

    if ($stmt->execute()) {
        echo "Password set successfully! You can now log in.";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
    } else {
        die("Invalid request.");
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set Password</title>
</head>
<body>
    <h2>Set Your Password</h2>
    <form action="set_password.php" method="post">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
        <label for="password">New Password:</label>
        <input type="password" id="password" name="password" required><br><br>
        <input type="submit" value="Set Password">
    </form>
</body>
</html>
