<?php
$conn = new mysqli('localhost', 'root', '', 'AttendanceSystem');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Admin credentials
$admin_username = 'alain@gmail.com'; // Change to username
$admin_password = password_hash('alain', PASSWORD_BCRYPT);

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
$stmt->bind_param("ss", $admin_username, $admin_password);

// Execute the statement
if ($stmt->execute()) {
    echo "Admin account created successfully.";
} else {
    echo "Error: " . $stmt->error;
}

// Close connections
$stmt->close();
$conn->close();
?>
