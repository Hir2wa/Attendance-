<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark Attendance</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }

        select, input[type="date"], input[type="submit"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #0044cc;
            color: #fff;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #0033aa;
        }

        .success-message, .error-message {
            margin-top: 20px;
            padding: 10px;
            border-radius: 5px;
            font-size: 16px;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Mark Attendance</h2>
        <form action="mark_attendance.php" method="POST">
            <select name="student_id" required>
                <option value="">Select Student</option>
                <?php
                // Connect to the database
                $conn = new mysqli('localhost', 'root', '', 'AttendanceSystem');
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                $result = $conn->query("SELECT id, name FROM students");
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                }
                $conn->close();
                ?>
            </select>

            <select name="lecturer_id" required>
                <option value="">Select Lecturer</option>
                <?php
                // Connect to the database
                $conn = new mysqli('localhost', 'root', '', 'AttendanceSystem');
                $result = $conn->query("SELECT id, name FROM lecturers");
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                }
                $conn->close();
                ?>
            </select>

            <input type="date" name="date" required>

            <select name="status" required>
                <option value="Present">Present</option>
                <option value="Absent">Absent</option>
                <option value="Late">Late</option>
            </select>

            <input type="submit" value="Mark Attendance">
        </form>

        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $student_id = $_POST['student_id'];
            $lecturer_id = $_POST['lecturer_id'];
            $date = $_POST['date'];
            $status = $_POST['status'];

            // Connect to the database
            $conn = new mysqli('localhost', 'root', '', 'AttendanceSystem');
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $sql = "INSERT INTO attendance_records (student_id, lecturer_id, date, status) VALUES ('$student_id', '$lecturer_id', '$date', '$status')";
            if ($conn->query($sql) === TRUE) {
                echo "<div class='success-message'>Attendance marked successfully</div>";
            } else {
                echo "<div class='error-message'>Error: " . $sql . "<br>" . $conn->error . "</div>";
            }
            $conn->close();
        }
        ?>
    </div>
</body>
</html>
