<?php
session_start(); // Start the session

include 'db_connection.php'; // Include the database connection

// Ensure the lecturer is logged in
if (!isset($_SESSION['email'])) {
    header('Location: lecturer_login.php');
    exit();
}

// Fetch the lecturer's ID
$email = $_SESSION['email'];
$stmt = $conn->prepare("SELECT id FROM lecturers WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $lecturer_id = $row['id'];
} else {
    echo "Lecturer not found.";
    exit();
}

$stmt->close();

// Fetch the list of students
$sql = "SELECT id, name FROM students";
$students = $conn->query($sql);

if (!$students) {
    die("Query failed: " . $conn->error);
}

// Initialize the selected student ID
$selected_student_id = isset($_GET['student_id']) ? $_GET['student_id'] : '';

// Fetch chat messages if a student is selected
$messages = null;
if ($selected_student_id) {
    $stmt = $conn->prepare("SELECT message, sender_role FROM messages WHERE (sender_id = ? AND sender_role = 'lecturer' AND receiver_id = ?) OR (sender_id = ? AND sender_role = 'student' AND receiver_id = ?) ORDER BY created_at ASC");
    $stmt->bind_param("iiii", $lecturer_id, $selected_student_id, $selected_student_id, $lecturer_id);
    $stmt->execute();
    $messages = $stmt->get_result();
    $stmt->close();
}

// Handle message status display
$message_status = isset($_GET['status']) ? $_GET['status'] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Chat with Student</title>
    <style>
        /* CSS styles here */
        body {
            font-family: Arial, sans-serif;
        }
        .student-list, .chat-window {
            margin-bottom: 20px;
        }
        .send-button {
            margin-top: 10px;
            padding: 10px 15px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        .send-button:hover {
            background-color: #0056b3;
        }
        .message-input {
            width: 100%;
            height: 100px;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .lecturer {
            color: blue;
        }
        .student {
            color: green;
        }
    </style>
</head>
<body>
    <h2>Chat with Student</h2>

    <div class="student-list">
        <form method="GET" action="chart_lecture.php">
            <label for="student">Select Student:</label>
            <select name="student_id" id="student" onchange="this.form.submit()">
                <option value="">-- Select Student --</option>
                <?php if ($students->num_rows > 0): ?>
                    <?php while ($student = $students->fetch_assoc()): ?>
                        <option value="<?php echo $student['id']; ?>" <?php echo $selected_student_id == $student['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($student['name']); ?>
                        </option>
                    <?php endwhile; ?>
                <?php else: ?>
                    <option value="">No students found</option>
                <?php endif; ?>
            </select>
        </form>
    </div>

    <?php if ($message_status === 'success'): ?>
        <p style="color: green;">Message sent successfully!</p>
    <?php elseif ($message_status === 'error'): ?>
        <p style="color: red;">Failed to send the message. Please try again.</p>
    <?php endif; ?>

    <div class="chat-window">
        <?php if ($selected_student_id && $messages && $messages->num_rows > 0): ?>
            <?php while ($message = $messages->fetch_assoc()): ?>
                <p class="<?php echo $message['sender_role'] === 'lecturer' ? 'lecturer' : 'student'; ?>">
                    <strong><?php echo $message['sender_role'] === 'lecturer' ? 'You' : 'Student'; ?>:</strong>
                    <?php echo htmlspecialchars($message['message']); ?>
                </p>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Select a student to start chatting.</p>
        <?php endif; ?>
    </div>

    <?php if ($selected_student_id): ?>
    <form id="chat-form" method="POST" action="send_message.php">
        <input type="hidden" name="receiver_id" value="<?php echo $selected_student_id; ?>">
        <input type="hidden" name="receiver_role" value="student">
        <input type="hidden" name="sender_id" value="<?php echo $lecturer_id; ?>">
        <input type="hidden" name="sender_role" value="lecturer">
        <textarea class="message-input" name="message" placeholder="Type your message here..."></textarea>
        <button type="submit" class="send-button">Send</button>
    </form>
    <?php endif; ?>
</body>
</html>
