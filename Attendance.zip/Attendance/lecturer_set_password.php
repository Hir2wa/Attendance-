<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'AttendanceSystem');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if email exists
    $stmt = $conn->prepare("SELECT email FROM lecturers WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Email exists, update password
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("UPDATE lecturers SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $hashed_password, $email);
        if ($stmt->execute()) {
            echo "Password set successfully. You can now log in.";
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "No account found with that email.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set Password</title>
    <style>
        /* Add your styling here */
    </style>
</head>
<body>
    <h2>Set Your Password</h2>
    <form action="lecturer_set_password.php" method="POST">
        Email: <input type="email" name="email" required><br>
        New Password: <input type="password" name="password" required><br>
        <input type="submit" value="Set Password">
    </form>
</body>
</html>
