<!-- dashboard.php -->
<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        header {
            background-color: #0044cc;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }
        header img {
            width: 100px;
            height: auto;
        }
        .content {
            margin: 40px 0;
        }
        h1 {
            font-size: 2.5em;
            margin: 20px 0;
        }
        form {
            margin: 20px 0;
        }
        input, select {
            padding: 10px;
            margin: 10px;
            font-size: 1em;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            font-size: 1em;
            color: #fff;
            background-color: #0044cc;
            text-decoration: none;
            border-radius: 5px;
            margin: 20px;
        }
        .btn:hover {
            background-color: #0033aa;
        }
    </style>
</head>
<body>
    <header>
        <img src="logo.png" alt="School Logo">
        <h1>Admin Dashboard</h1>
    </header>
    
    <div class="container">
        <div class="content">
            <a href="logout.php" class="btn">Logout</a>
            
            <h3>Register Student</h3>
            <form action="dashboard.php" method="POST">
                Name: <input type="text" name="student_name" required><br>
                Email: <input type="email" name="student_email" required><br>
                Group ID: <input type="text" name="student_group_id"><br>
                <input type="submit" name="register_student" value="Register Student">
            </form>

            <h3>Register Lecturer</h3>
            <form action="dashboard.php" method="POST">
                Name: <input type="text" name="lecturer_name" required><br>
                Email: <input type="email" name="lecturer_email" required><br>
                Department: <input type="text" name="lecturer_department"><br>
                <input type="submit" name="register_lecturer" value="Register Lecturer">
            </form>

            <h3>Mark Attendance</h3>
            <form action="dashboard.php" method="POST">
                Student:
                <select name="attendance_student_id" required>
                    <option value="">Select Student</option>
                    <?php
                    $conn = new mysqli('localhost', 'root', '', 'AttendanceSystem');
                    $result = $conn->query("SELECT id, name FROM students");
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                    }
                    ?>
                </select><br><br>

                Lecturer:
                <select name="attendance_lecturer_id" required>
                    <option value="">Select Lecturer</option>
                    <?php
                    $result = $conn->query("SELECT id, name FROM lecturers");
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                    }
                    ?>
                </select><br><br>

                Date: <input type="date" name="attendance_date" required><br><br>
                Status: 
                <select name="attendance_status" required>
                    <option value="Present">Present</option>
                    <option value="Absent">Absent</option>
                    <option value="Late">Late</option>
                </select><br><br>

                <input type="submit" name="mark_attendance" value="Mark Attendance">
            </form>

            <h3>View Attendance Records</h3>
            <form action="dashboard.php" method="GET">
                Student:
                <select name="view_student_id">
                    <option value="">Select Student</option>
                    <?php
                    $result = $conn->query("SELECT id, name FROM students");
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                    }
                    ?>
                </select><br><br>

                Date: <input type="date" name="view_date"><br><br>
                <input type="submit" name="view_records" value="View Records">
            </form>

            <?php
            // Handle form submissions
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                if (isset($_POST['register_student'])) {
                    $name = $_POST['student_name'];
                    $email = $_POST['student_email'];
                    $group_id = $_POST['student_group_id'];

                    $sql = "INSERT INTO students (name, email, group_id) VALUES ('$name', '$email', '$group_id')";
                    if ($conn->query($sql) === TRUE) {
                        echo "Student registered successfully.";
                    } else {
                        echo "Error: " . $conn->error;
                    }
                }

                if (isset($_POST['register_lecturer'])) {
                    $name = $_POST['lecturer_name'];
                    $email = $_POST['lecturer_email'];
                    $department = $_POST['lecturer_department'];

                    $sql = "INSERT INTO lecturers (name, email, department) VALUES ('$name', '$email', '$department')";
                    if ($conn->query($sql) === TRUE) {
                        echo "Lecturer registered successfully.";
                    } else {
                        echo "Error: " . $conn->error;
                    }
                }

                if (isset($_POST['mark_attendance'])) {
                    $student_id = $_POST['attendance_student_id'];
                    $lecturer_id = $_POST['attendance_lecturer_id'];
                    $date = $_POST['attendance_date'];
                    $status = $_POST['attendance_status'];

                    $sql = "INSERT INTO attendance_records (student_id, lecturer_id, date, status) VALUES ('$student_id', '$lecturer_id', '$date', '$status')";
                    if ($conn->query($sql) === TRUE) {
                        echo "Attendance marked successfully.";
                    } else {
                        echo "Error: " . $conn->error;
                    }
                }
            }

            // Handle viewing records
            if (isset($_GET['view_records'])) {
                $student_id = $_GET['view_student_id'];
                $date = $_GET['view_date'];

                $sql = "SELECT students.name AS student_name, lecturers.name AS lecturer_name, attendance_records.date, attendance_records.status
                        FROM attendance_records
                        JOIN students ON attendance_records.student_id = students.id
                        JOIN lecturers ON attendance_records.lecturer_id = lecturers.id
                        WHERE 1=1";
                
                if ($student_id) {
                    $sql .= " AND attendance_records.student_id = '$student_id'";
                }
                if ($date) {
                    $sql .= " AND attendance_records.date = '$date'";
                }

                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    echo "<table border='1'>
                            <tr>
                                <th>Student Name</th>
                                <th>Lecturer Name</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>";
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>" . $row['student_name'] . "</td>
                                <td>" . $row['lecturer_name'] . "</td>
                                <td>" . $row['date'] . "</td>
                                <td>" . $row['status'] . "</td>
                              </tr>";
                    }
                    echo "</table>";
                } else {
                    echo "No records found.";
                }
            }

            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
