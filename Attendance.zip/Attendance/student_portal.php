<?php
session_start(); // Start the session

// Check if the student is logged in
if (!isset($_SESSION['email'])) {
    header('Location: student_login.php');
    exit();
}

// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'AttendanceSystem');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the logged-in student's email
$email = $_SESSION['email'];

// Fetch the student's ID
$stmt = $conn->prepare("SELECT id FROM students WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $student_id = $row['id'];
} else {
    echo "Student not found.";
    exit();
}

$stmt->close();

// Fetch the attendance records for the student
$stmt = $conn->prepare("SELECT date, status FROM attendance_records WHERE student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Attendance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Your Attendance Records</h2>
    
    <table>
        <tr>
            <th>Date</th>
            <th>Status</th>
        </tr>
        <?php
        // Display the attendance records
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['date']) . "</td>";
            echo "<td>" . htmlspecialchars($row['status']) . "</td>";
            echo "</tr>";
        }
        ?>
    </table>

    <br>
    <a href="chart_student.php">chat</a>
    <a href="logout.php">Logout</a>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
