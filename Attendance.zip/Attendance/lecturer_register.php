<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Lecturer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .registration-container {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 100%;
            max-width: 500px;
            text-align: center;
        }
        .registration-container h2 {
            margin-top: 0;
            color: #0044cc; /* Blue color for the heading */
        }
        .registration-container form {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }
        .registration-container label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
            display: block;
            width: 100%;
        }
        .registration-container input[type="text"],
        .registration-container input[type="email"],
        .registration-container select {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1em;
            width: calc(100% - 22px); /* Adjust width for padding and border */
        }
        .registration-container input[type="submit"] {
            padding: 10px;
            font-size: 1em;
            color: #fff;
            background-color: #0044cc;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .registration-container input[type="submit"]:hover {
            background-color: #0033aa;
        }
        .success-message {
            color: #28a745;
            margin-top: 15px;
        }
        .error-message {
            color: #dc3545;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="registration-container">
        <h2>Register Lecturer</h2>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $department = $_POST['department'];
            $course = $_POST['course'];
            $group = $_POST['group'];

            // Connect to the database
            $conn = new mysqli('localhost', 'root', '', 'AttendanceSystem');

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Insert lecturer record with course and group
            $stmt = $conn->prepare("INSERT INTO lecturers (name, email, department, course, group_name) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $name, $email, $department, $course, $group);

            if ($stmt->execute()) {
                echo "<div class='success-message'>New lecturer registered successfully.</div>";
            } else {
                echo "<div class='error-message'>Error: " . $stmt->error . "</div>";
            }

            $stmt->close();
            $conn->close();
        }
        ?>
        <form action="lecturer_register.php" method="POST">
            <label for="name">Name:</label>
            <input type="text" name="name" required><br>

            <label for="email">Email:</label>
            <input type="email" name="email" required><br>

            <label for="department">Department:</label>
            <input type="text" name="department"><br>

            <label for="course">Course:</label>
            <input type="text" name="course" required><br>

            <label for="group">Group:</label>
            <select name="group" required>
                <option value="">Select Group</option>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
                <option value="E">E</option>
            </select><br>

            <input type="submit" value="Register">
        </form>
    </div>
</body>
</html>
