<?php
session_start();
$conn = new mysqli("localhost", "root", "", "attendancesystem");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure session variable is set
if (!isset($_SESSION['lecturer_id'])) {
    die("Invalid request.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $lecturer_id = $_SESSION['lecturer_id'];
    $new_password = $_POST['new_password'];

    if (empty($new_password)) {
        echo "Password cannot be empty.";
        exit();
    }

    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("UPDATE lecturers SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $hashed_password, $lecturer_id);

    if ($stmt->execute()) {
        echo "Password set successfully!";
        // Redirect or display success message
        session_unset(); // Clear session data
        session_destroy(); // Destroy session
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Invalid request.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set Your Password</title>
</head>
<body>
    <h2>Create Your Password</h2>
    <form method="post" action="">
        <label for="new_password">New Password:</label>
        <input type="password" id="new_password" name="new_password" required><br><br>

        <input type="submit" value="Set Password">
    </form>
</body>
</html>
