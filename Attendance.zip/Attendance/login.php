<!-- login.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <form action="login.php" method="POST">
        Username: <input type="text" name="username" required><br>
        Password: <input type="password" name="password" required><br>
        <input type="submit" value="Login">
    </form>

    <?php
    session_start();

    // Static credentials for demo purposes
    $admin_username = 'admin';
    $admin_password = 'password'; // You should hash passwords in a real application

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        if ($username === $admin_username && $password === $admin_password) {
            $_SESSION['logged_in'] = true;
            header('Location: dashboard.php');
        } else {
            echo "Invalid credentials.";
        }
    }
    ?>
</body>
</html>
