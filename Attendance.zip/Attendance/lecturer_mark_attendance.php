<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mark Attendance</title>
</head>
<body>
    <h2>Mark Attendance</h2>
    <form action="lecturer_mark_attendance.php" method="POST">
        Student: 
        <select name="student_id" required>
            <option value="">Select Student</option>
            <?php
            // Connect to the database
            $conn = new mysqli('localhost', 'root', '', 'AttendanceSystem');

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch students based on lecturer's courses
            // Assuming you have a way to get lecturer's courses
            $lecturer_id = $_SESSION['lecturer_id']; // Assume lecturer ID is stored in session
            $result = $conn->query("
                SELECT students.id, students.name 
                FROM students 
                JOIN student_courses ON students.id = student_courses.student_id
                JOIN courses ON student_courses.course_id = courses.id
                WHERE courses.lecturer_id = '$lecturer_id'
            ");

            // Populate the dropdown with students
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['id'] . "'>" . htmlspecialchars($row['name']) . "</option>";
            }

            $conn->close();
            ?>
        </select><br><br>

        Date: <input type="date" name="date" required><br><br>
        Status: 
        <select name="status" required>
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
            <option value="Late">Late</option>
        </select><br><br>

        <input type="submit" value="Mark Attendance">
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $student_id = $_POST['student_id'];
        $date = $_POST['date'];
        $status = $_POST['status'];

        // Connect to the database
        $conn = new mysqli('localhost', 'root', '', 'AttendanceSystem');

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Insert attendance record
        $sql = "INSERT INTO attendance_records (student_id, lecturer_id, date, status) VALUES ('$student_id', '$lecturer_id', '$date', '$status')";

        if ($conn->query($sql) === TRUE) {
            echo "Attendance marked successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    }
    ?>
</body>
</html>
