<?php
session_start();
$conn = new mysqli("localhost", "root", "", "attendancesystem");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password FROM lecturers WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($lecturer_id, $stored_password);
        $stmt->fetch();

        if (empty($stored_password)) {
            $_SESSION['lecturer_id'] = $lecturer_id;
            header("Location: create_password.php");
            exit();
        } else {
            if (password_verify($password, $stored_password)) {
                $_SESSION['lecturer_id'] = $lecturer_id;
                $_SESSION['lecturer_email'] = $email; // Store email in session
                $_SESSION['lecturer_logged_in'] = true; // Set logged-in status
                header("Location: lecturer_dashboard.php");
                exit();
            } else {
                echo "Invalid email or password.";
            }
        }
    } else {
        echo "No account found with this email.";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lecturer Login</title>
</head>
<body>
    <h2>Lecturer Login</h2>
    <form method="post" action="">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>

        <input type="submit" value="Login">
    </form>
</body>
</html>
