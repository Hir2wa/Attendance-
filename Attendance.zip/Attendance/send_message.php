<?php
session_start(); // Start the session

include 'db_connection.php'; // Include the database connection

// Check if required POST data is set
if (isset($_POST['receiver_id'], $_POST['receiver_role'], $_POST['sender_id'], $_POST['sender_role'], $_POST['message'])) {
    $receiver_id = $_POST['receiver_id'];
    $receiver_role = $_POST['receiver_role'];
    $sender_id = $_POST['sender_id'];
    $sender_role = $_POST['sender_role'];
    $message = $_POST['message'];

    // Prepare and execute the insert query
    $stmt = $conn->prepare("INSERT INTO messages (sender_id, sender_role, receiver_id, receiver_role, message) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issis", $sender_id, $sender_role, $receiver_id, $receiver_role, $message);

    if ($stmt->execute()) {
        header("Location: chart_student.php?student_id=$receiver_id&status=success");
    } else {
        header("Location: chart_lecture.php?student_id=$receiver_id&status=error");
    }

    $stmt->close();
} else {
    header("Location: chart_lecture.php?status=error");
}
$conn->close();
?>
