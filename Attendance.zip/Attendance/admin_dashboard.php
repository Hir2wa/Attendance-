<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // If not logged in, redirect to the login page
    header("Location: admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url(''); /* Background image */
            background-size: cover;
            background-position: center;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .dashboard-container {
            background: rgba(0, 0, 0, 0.7); /* Semi-transparent background */
            padding: 20px;
            border-radius: 8px;
            width: 100%;
            max-width: 600px;
            text-align: center;
        }
        .dashboard-header {
            background-color: #0044cc; /* Blue header */
            padding: 15px;
            color: #fff;
            border-radius: 8px 8px 0 0;
        }
        .dashboard-container ul {
            list-style-type: none;
            padding: 0;
            margin: 20px 0;
        }
        .dashboard-container ul li {
            margin-bottom: 10px;
        }
        .dashboard-container ul li a {
            color: #fff; /* White links */
            text-decoration: none;
            font-size: 1.2em;
        }
        .dashboard-container ul li a:hover {
            text-decoration: underline;
        }
        .dashboard-container p {
            margin-top: 20px;
        }
        .dashboard-container p a {
            color: #ff0000; /* Red logout link */
            text-decoration: none;
            font-size: 1.1em;
        }
        .dashboard-container p a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="dashboard-header">
            <h2>Admin Dashboard</h2>
        </div>
        <ul>
            <li><a href="register.html">Register New Student</a></li>
            <li><a href="lecturer_register.php">Register New Lecturer</a></li>
            <li><a href="mark_attendance.php">Mark Attendance</a></li>
            <li><a href="view_attendance.php">View Attendance Records</a></li>
        </ul>
        <p><a href="logout.php">Logout</a></p>
    </div>
</body>
</html>
