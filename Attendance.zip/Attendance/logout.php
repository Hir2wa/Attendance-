<?php
session_start();
session_unset();
session_destroy();

// Redirect to the general login selection page or homepage
header('Location: index.html'); // Or any page where users can choose their role again
exit();
?>
