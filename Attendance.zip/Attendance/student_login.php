<?php
session_start(); // Start the session

// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'AttendanceSystem');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare SQL query to check if the student exists
    $stmt = $conn->prepare("SELECT id, password FROM students WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $hashed_password = $row['password'];

        if (empty($hashed_password)) {
            // Prompt to set password if it doesn't exist
            if (isset($_POST['new_password'])) {
                $new_password = password_hash($_POST['new_password'], PASSWORD_BCRYPT);

                // Update the password in the database
                $update_stmt = $conn->prepare("UPDATE students SET password = ? WHERE id = ?");
                $update_stmt->bind_param("si", $new_password, $row['id']);
                if ($update_stmt->execute()) {
                    echo "Password set successfully. Please login again.";
                    $update_stmt->close();
                } else {
                    echo "Failed to set password. Please try again.";
                }
            } else {
                echo "Please set your password.";
                // Display the password set form
                ?>
                <div class="login-container">
                    <h2>Set Password</h2>
                    <form action="student_login.php" method="POST">
                        <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
                        <label for="new_password">New Password:</label>
                        <input type="password" name="new_password" required><br><br>
                        <input type="submit" value="Set Password">
                    </form>
                </div>
                <?php
                exit();
            }
        } else {
            // If password exists, verify it
            if (password_verify($password, $hashed_password)) {
                $_SESSION['student_id'] = $row['id'];
                $_SESSION['email'] = $email;

                // Redirect to student portal
                header("Location: student_portal.php");
                exit();
            } else {
                $error_message = "Invalid password.";
            }
        }
    } else {
        $error_message = "No account found with that email.";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url(''); /* Background image */
            background-size: cover;
            background-position: center;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-container {
            background: rgba(0, 0, 0, 0.6); /* Semi-transparent background */
            padding: 20px;
            border-radius: 8px;
            width: 100%;
            max-width: 400px;
        }
        .login-container h2 {
            margin-top: 0;
        }
        .login-container form {
            display: flex;
            flex-direction: column;
        }
        .login-container input[type="email"],
        .login-container input[type="password"] {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1em;
        }
        .login-container input[type="submit"] {
            padding: 10px;
            font-size: 1em;
            color: #fff;
            background-color: #0044cc;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .login-container input[type="submit"]:hover {
            background-color: #0033aa;
        }
        .error-message {
            color: #ff0000;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Student Login</h2>
        <?php if (isset($error_message)): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form action="student_login.php" method="POST">
            Email: <input type="email" name="email" required><br>
            Password: <input type="password" name="password" required><br>
            <input type="submit" value="Login">
        </form>
    </div>
</body>
</html>
