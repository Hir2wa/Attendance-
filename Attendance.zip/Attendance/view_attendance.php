<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Attendance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .container {
            width: 90%;
            max-width: 800px;
            background-color: #fff;
            padding: 20px;
            margin: 30px auto;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            flex-grow: 1;
        }

        h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #333;
            text-align: center;
        }

        form {
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
        }

        label {
            font-weight: bold;
            margin-right: 10px;
        }

        select, input[type="date"], input[type="submit"] {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        select {
            flex: 1;
            margin-right: 10px;
        }

        input[type="date"] {
            flex: 1;
            margin-right: 10px;
        }

        input[type="submit"] {
            background-color: #0044cc;
            color: #fff;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
            flex-shrink: 0;
        }

        input[type="submit"]:hover {
            background-color: #0033aa;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
            color: #333;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .no-records {
            text-align: center;
            padding: 20px;
            color: #777;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: auto;
            font-size: 14px;
        }

        footer a {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>View Attendance Records</h2>
        
        <form action="view_attendance.php" method="GET">
            <label for="student_id">Student:</label>
            <select name="student_id">
                <option value="">Select Student</option>
                <?php
                // Connect to the database
                $conn = new mysqli('localhost', 'root', '', 'AttendanceSystem');

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch students
                $result = $conn->query("SELECT id, name FROM students");

                // Populate the dropdown with students
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                }

                $conn->close();
                ?>
            </select>

            <label for="date">Date:</label>
            <input type="date" name="date">

            <input type="submit" value="View Records">
        </form>

        <?php
        if (isset($_GET['student_id']) || isset($_GET['date'])) {
            $student_id = $_GET['student_id'];
            $date = $_GET['date'];

            // Connect to the database
            $conn = new mysqli('localhost', 'root', '', 'AttendanceSystem');

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Build the query based on the provided filters
            $sql = "SELECT students.id AS student_id, students.name AS student_name, attendance_records.date, attendance_records.status
                    FROM attendance_records
                    JOIN students ON attendance_records.student_id = students.id
                    WHERE 1=1";
                    
            if ($student_id) {
                $sql .= " AND attendance_records.student_id = '$student_id'";
            }
            if ($date) {
                $sql .= " AND attendance_records.date = '$date'";
            }

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<table>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . htmlspecialchars($row['student_id']) . "</td>
                            <td>" . htmlspecialchars($row['student_name']) . "</td>
                            <td>" . htmlspecialchars($row['date']) . "</td>
                            <td>" . htmlspecialchars($row['status']) . "</td>
                          </tr>";
                }
                echo "</table>";
            } else {
                echo "<div class='no-records'>No records found.</div>";
            }

            $conn->close();
        }
        ?>
    </div>

    
</body>
</html>
